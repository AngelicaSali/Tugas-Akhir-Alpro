#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include "boolean.h"
#include "users.h"
#include "members.h"
#include "barang.h"
#include "transactions.h"

char *home[6] = {"\n\n\t\t\t\tBeranda\n\n",NULL,NULL,NULL,NULL,NULL};
char *kelolaLaporan[6] = {"\n\n\t\t\t\tBeranda","Kelola Transaksi","Kelola Laporan\n\n",NULL,NULL,NULL};
char *kelolaPenjualan[6] = {"\n\n\t\t\t\tBeranda","Kelola Transaksi","Kelola Penjualan\n\n",NULL,NULL,NULL};
char *kelola_transaksi[6] = {"\n\n\t\t\t\tBeranda","Kelola Transaksi\n\n",NULL,NULL,NULL,NULL};
char *kelola_barang[6] = {"\n\n\t\t\t\tBeranda","Kelola Barang\n\n",NULL,NULL,NULL,NULL};
char *kelola_user[6] = {"\n\n\t\t\t\tBeranda","Kelola User\n\n",NULL,NULL,NULL,NULL};
char *hapusUser[6] = {"\n\n   Beranda","Kelola User","Hapus User\n\n\n",NULL,NULL,NULL};
char *hapus[6] = {"\n\n   Beranda","Kelola Transaksi","Kelola Pembelian","Hapus Pembelian\n\n",NULL,NULL};
char *laporan[6] = {"\n\n    Beranda","Kelola Transaksi","Laporan\n\n",NULL,NULL,NULL};
char *hapusJual[6] = {"\n\n   Beranda","Kelola Transaksi","Kelola Penjualan","Hapus Penjualan\n\n",NULL,NULL};
char *tampilkanBarang[6] = {"\n\n   Beranda","Kelola Barang","Tampilkan Barang\n\n\n",NULL,NULL,NULL};
char *ubahBarang[6] = {"\n\n   Beranda","Kelola Barang","Ubah Barang\n\n\n",NULL,NULL,NULL};
char *ubahUser[6] = {"\n\n   Beranda","Kelola User","Ubah User\n\n\n",NULL,NULL,NULL};
char *hapusBarang[6] = {"\n\n   Beranda","Kelola Barang","Hapus Barang\n\n\n",NULL,NULL,NULL};

void MenuAdmin(Users UserNow);
static int status = false, counterRow;
char ulangi;

int main(){
	Users UserNow;
	char ulangi;

	login:
	do{
		if(Login(&UserNow)){
			printf("\n\n  Login Berhasil\n");
			printf("\n  Klik enter untuk masuk ke halaman dashboard ..."); getch();
			system("cls");
            MenuAdmin(UserNow);
            if(status==true) goto login;
			}
		else {
			printf("\n\n  Username atau Password Salah!\n");
		}
		ulangiUlangi:
		printf("\n  Ulangi Login [Y/T] : "); fflush(stdin); scanf("%c", &ulangi);
		if(ulangi=='t' || ulangi=='T' || ulangi=='y' || ulangi=='Y'){
			system("cls");
		} else {
			goto ulangiUlangi;
		}
	} while(ulangi=='Y' || ulangi=='y');
	return 0;
}

void MenuAdmin(Users UserNow){
	int pilih;
	char ulangi;
	MarqueeText("\n\n\n\n\n\n\n\n\n\n\n\n\n\t\t\t\t\tSelamat Datang, ",13999900);
	MarqueeText(UserNow.nama,13999900);
	system("cls");
	menuAdmin:
	Breadcrumb(home);
	printf("\t\t\t        \xda\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xbf\n");
	printf("\t\t\t        \xb3               TOKO ANGRI GADGET                   \xb3\n");
	printf("\t\t\t        \xb3        Jl.Kampus Bukit UNUD Jimbaran              \xb3\n");
	printf("\t\t\t        \xb3                 Badung-Bali                        \xb3\n");
	printf("\t\t\t        \xb3\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xb3\n");
	printf("\t\t\t        \xb3             ====== Menu Admin ======              \xb3\n");
	printf("\t\t\t        \xb3                                                   \xb3\n");
	printf("\t\t\t        \xb3                1. Kelola User                     \xb3\n");
    printf("\t\t\t        \xb3                                                   \xb3\n");
	printf("\t\t\t        \xb3                2. Kelola Barang                   \xb3\n");
	printf("\t\t\t        \xb3                                                   \xb3\n");
	printf("\t\t\t        \xb3                3. Kelola Transaksi                \xb3\n");
	printf("\t\t\t        \xb3                                                   \xb3\n");
	printf("\t\t\t        \xb3                4. Pedoman Pengguna                \xb3\n");
	printf("\t\t\t        \xb3                                                   \xb3\n");
	printf("\t\t\t        \xb3                5. Ubah Tampilan                   \xb3\n");
	printf("\t\t\t        \xb3                                                   \xb3\n");
	printf("\t\t\t        \xb3                6. Logout                          \xb3\n");
	printf("\t\t\t        \xb3                                                   \xb3\n");
    printf("\t\t\t        \xc0\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xd9\n");
    MarqueeText("\t\t\t        \xb3\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xb3\n",4000000);
	printf("\t\t\t                           Pilih Menu : "); scanf("%d", &pilih);
	system("cls");
	switch(pilih){
		case 1:
			menuUser:
			Breadcrumb(kelola_user);
            printf("\t\t\t        \xda\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xbf\n");
            printf("\t\t\t        \xb3               TOKO ANGRI GADGET                   \xb3\n");
            printf("\t\t\t        \xb3        Jl.Kampus Bukit UNUD Jimbaran              \xb3\n");
            printf("\t\t\t        \xb3                 Badung-Bali                        \xb3\n");
            printf("\t\t\t        \xb3\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xb3\n");
		    printf("\t\t\t        \xb3             ====== Menu Admin ======              \xb3\n");
			printf("\t\t\t        \xb3                                                   \xb3\n");
			printf("\t\t\t        \xb3                1. Tambah User                     \xb3\n");
			printf("\t\t\t        \xb3                                                   \xb3\n");
			printf("\t\t\t        \xb3                2. Tampilkan User                  \xb3\n");
			printf("\t\t\t        \xb3                                                   \xb3\n");
			printf("\t\t\t        \xb3                3. Ubah User                       \xb3\n");
			printf("\t\t\t        \xb3                                                   \xb3\n");
			printf("\t\t\t        \xb3                4. Hapus User                      \xb3\n");
			printf("\t\t\t        \xb3                                                   \xb3\n");
			printf("\t\t\t        \xb3                5. Cari User                       \xb3\n");
			printf("\t\t\t        \xb3                                                   \xb3\n");
			printf("\t\t\t        \xb3                0. Kembali                         \xb3\n");
			printf("\t\t\t        \xb3                                                   \xb3\n");
			printf("\t\t\t        \xc0\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xd9\n");
			MarqueeText("\t\t\t        \xb3\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xb3\n",3999900);
			printf("\t\t\t                           Pilih Menu : "); scanf("%d", &pilih);
			system("cls");
			switch(pilih){
				case 0:
					goto menuAdmin;
				break;
				case 1:
					TambahUser();
				break;
				case 2:
					counterRow = 13;
					TampilkanUser('n',&counterRow);
					printf("\n");
				break;
				case 3:
					Breadcrumb(ubahUser);
					UbahUser();
				break;
				case 4:
					Breadcrumb(hapusUser);
					HapusUser();
					printf("\n");
				break;
				case 5:
					CariUser();
					printf("\n");
				break;
				default:
					goto menuUser;
				break;
			}
			printf("   \xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4 \n");
			printf("   Tekan Mana Saja Untuk Kembali . . . "); getch();
			system("cls");
			goto menuUser;
		break;

		case 2:
			menuBarang:
			Breadcrumb(kelola_barang);
            printf("\t\t\t        \xda\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xbf\n");
            printf("\t\t\t        \xb3               TOKO ANGRI GADGET                   \xb3\n");
            printf("\t\t\t        \xb3        Jl.Kampus Bukit UNUD Jimbaran              \xb3\n");
            printf("\t\t\t        \xb3                 Badung-Bali                        \xb3\n");
            printf("\t\t\t        \xb3\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xb3\n");
		    printf("\t\t\t        \xb3             ====== Menu Admin ======              \xb3\n");
			printf("\t\t\t        \xb3                                                   \xb3\n");
			printf("\t\t\t        \xb3                1. Tambah Barang                   \xb3\n");
			printf("\t\t\t        \xb3                                                   \xb3\n");
			printf("\t\t\t        \xb3                2. Tampilkan Barang                \xb3\n");
			printf("\t\t\t        \xb3                                                   \xb3\n");
			printf("\t\t\t        \xb3                3. Ubah Barang                     \xb3\n");
			printf("\t\t\t        \xb3                                                   \xb3\n");
			printf("\t\t\t        \xb3                4. Hapus Barang                    \xb3\n");
			printf("\t\t\t        \xb3                                                   \xb3\n");
            printf("\t\t\t        \xb3                0. Kembali                         \xb3\n");
			printf("\t\t\t        \xb3                                                   \xb3\n");
			printf("\t\t\t        \xc0\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xd9\n");
			MarqueeText("\t\t\t        \xb3\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xb3\n",3999900);
			printf("\t\t\t                           Pilih Menu : "); scanf("%d", &pilih);
			system("cls");
			switch(pilih){
				case 0:
					goto menuAdmin;
				break;
				case 1:
					TambahBarang('y');
				break;
				case 2:
					Breadcrumb(tampilkanBarang);
					counterRow = 13;
					TampilkanBarang('n','t', &counterRow);
					printf("\n");
				break;
				case 3:
					Breadcrumb(ubahBarang);
					UbahBarang();
					printf("\n");
				break;
				case 4:
					Breadcrumb(hapusBarang);
					HapusBarang();
				break;
				default:
					goto menuBarang;
				break;
			}
			printf("   \xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4 \n");
			printf("   Tekan Mana Saja Untuk Kembali . . . "); getch();
			system("cls");
			goto menuBarang;
		break;

		case 3:
			menuTransaksi:
			Breadcrumb(kelola_transaksi);
            printf("\t\t\t        \xda\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xbf\n");
            printf("\t\t\t        \xb3               TOKO ANGRI GADGET                   \xb3\n");
            printf("\t\t\t        \xb3        Jl.Kampus Bukit UNUD Jimbaran              \xb3\n");
            printf("\t\t\t        \xb3                 Badung-Bali                        \xb3\n");
            printf("\t\t\t        \xb3\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xb3\n");
		    printf("\t\t\t        \xb3             ====== Menu Admin ======              \xb3\n");
			printf("\t\t\t        \xb3                                                   \xb3\n");
			printf("\t\t\t        \xb3                1. Penjualan                       \xb3\n");
			printf("\t\t\t        \xb3                                                   \xb3\n");
			printf("\t\t\t        \xb3                2. Laporan                         \xb3\n");
			printf("\t\t\t        \xb3                                                   \xb3\n");
			printf("\t\t\t        \xb3                0. Kembali                         \xb3\n");
			printf("\t\t\t        \xb3                                                   \xb3\n");
			printf("\t\t\t        \xc0\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xd9\n");
			MarqueeText("\t\t\t        \xb3\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xb3\n",3999900);
			printf("\t\t\t                           Pilih Menu : "); scanf("%d", &pilih);
			system("cls");
			switch(pilih){
				case 0:
					goto menuAdmin;
				break;
				case 1:
				    menuTransaksijual:
			    	Breadcrumb(kelolaPenjualan);
       		   	   	printf("\t\t\t        \xda\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xbf\n");
                    printf("\t\t\t        \xb3               TOKO ANGRI GADGET                   \xb3\n");
                    printf("\t\t\t        \xb3        Jl.Kampus Bukit UNUD Jimbaran              \xb3\n");
                    printf("\t\t\t        \xb3                 Badung-Bali                        \xb3\n");
                    printf("\t\t\t        \xb3\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xb3\n");
	 			    printf("\t\t\t        \xb3             ====== Menu Admin ======              \xb3\n");
					printf("\t\t\t        \xb3                                                   \xb3\n");
					printf("\t\t\t        \xb3                1. Penjualan                       \xb3\n");
					printf("\t\t\t        \xb3                                                   \xb3\n");
					printf("\t\t\t        \xb3                2. Tampilkan Data Jual             \xb3\n");
					printf("\t\t\t        \xb3                                                   \xb3\n");
					printf("\t\t\t        \xb3                0. Kembali                         \xb3\n");
					printf("\t\t\t        \xb3                                                   \xb3\n");
					printf("\t\t\t        \xc0\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xd9\n");
					MarqueeText("\t\t\t        \xb3\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xb3\n",3999900);
					printf("\t\t\t                           Pilih Menu : "); scanf("%d", &pilih);
					system("cls");
					switch(pilih){
						case 0:
							goto menuTransaksi;
							break;
						case 1:
			            	Penjualan();
			            	printf("\n");
		            	break;
						case 2:
							counterRow = 13;
							TampilkanPenjualan('n','t', &counterRow);
							printf("\n");
						break;
						default:
						    goto menuTransaksijual;
						break;
					}
					printf("   \xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4 \n");
					printf("   Tekan Mana Saja Untuk Kembali . . . "); getch();
					system("cls");
					goto menuTransaksijual;
				break;

				case 2:
				    menuTransaksilapor:
				    Breadcrumb(kelolaLaporan);
       		   	    printf("\t\t\t        \xda\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xbf\n");
                    printf("\t\t\t        \xb3               TOKO ANGRI GADGET                   \xb3\n");
                    printf("\t\t\t        \xb3        Jl.Kampus Bukit UNUD Jimbaran              \xb3\n");
                    printf("\t\t\t        \xb3                 Badung-Bali                        \xb3\n");
                    printf("\t\t\t        \xb3\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xb3\n");
	 			    printf("\t\t\t        \xb3             ====== Menu Admin ======              \xb3\n");
					printf("\t\t\t        \xb3                                                   \xb3\n");
					printf("\t\t\t        \xb3                1. Laporan                         \xb3\n");
					printf("\t\t\t        \xb3                                                   \xb3\n");
					printf("\t\t\t        \xb3                0. Kembali                         \xb3\n");
					printf("\t\t\t        \xb3                                                   \xb3\n");
					printf("\t\t\t        \xc0\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xd9\n");
					MarqueeText("\t\t\t        \xb3\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xb3\n",3999900);
					printf("\t\t\t                           Pilih Menu : "); scanf("%d", &pilih);
					system("cls");
					switch(pilih){
						case 0:
							goto menuTransaksi;
						break;
						case 1:
							Breadcrumb(laporan);
			            	Laporan();
			            	printf("\n\n ");
						break;
						default:
						    goto menuTransaksilapor;
						break;
					}
					printf("   \xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4 \n");
					printf("   Tekan Mana Saja Untuk Kembali . . . "); getch();
					system("cls");
					goto menuTransaksilapor;
				break;
			}
		case 4:
			panduan("txt/ADMIN.txt");
			printf("\n   \xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4 \n");
			printf("   Tekan Mana Saja Untuk Kembali . . . "); getch();
			system("cls");
			goto menuAdmin;
		break;
		case 5:
			system("cls");
		    printf("\t\t\t        \xb3             ====== TAMPILAN ======              \xb3\n");
			printf("\t\t\t        \xb3                                                 \xb3\n");
			printf("\t\t\t        \xb3                1. LIGHT MODE                    \xb3\n");
			printf("\t\t\t        \xb3                                                 \xb3\n");
			printf("\t\t\t        \xb3                2. DARK MODE                     \xb3\n");
			printf("\t\t\t        \xc0\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xd9\n");
			MarqueeText("\t\t\t        \xb3\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xb3\n",3999900);
			printf("\t\t\t                           Pilih Menu : "); scanf("%d", &pilih);
			switch(pilih){
				case 1:
					system("color F0");
				break;
				case 2:
					system("color 07");
				break;
				default:
			    	goto menuAdmin;
			    break;
			}
			printf("\n   \xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4 \n");
			printf("   Tekan Mana Saja Untuk Kembali . . . "); getch();
			system("cls");
			goto menuAdmin;
		break;
		case 6:
			Logout(&UserNow, &status);
		break;
		default:
		    fflush(stdin);
			goto menuAdmin;
		break;
	}
}
