#ifndef transactions_H
#define transactions_H
#include "tools.h"
#include "barang.h"

typedef struct {
	Barang barang;
	int qty;
} Belanjaan;


typedef struct{
	int id_penjualan, total_harga;
	Belanjaan belanjaan[10];
	Timestamp tanggal_pembelian;
	char nama_pembeli[100], keterangan[100], no_telp[12];
} Jual;


void HapusJual();


int IsRusak(int kondisi);

FILE TampilkanPenjualan(char mode, char isJual, int *counterRow);



void TableHeaderPenjualan(int yCoordAwal, int *barisTerakhir);



void Penjualan();



void Pengembalian();



void Laporan();

void Struk(char mode, Jual penjualan, int counter, int dibayarkan);

int IsGaransi(Jual jual);

#endif
